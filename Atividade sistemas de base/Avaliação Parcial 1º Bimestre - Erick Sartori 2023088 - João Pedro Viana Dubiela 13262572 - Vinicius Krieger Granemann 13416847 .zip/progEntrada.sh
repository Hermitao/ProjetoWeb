#!/usr/bin/bash

clear
printf "Insira um número de 2 a 10\n"

./progProcesso.sh