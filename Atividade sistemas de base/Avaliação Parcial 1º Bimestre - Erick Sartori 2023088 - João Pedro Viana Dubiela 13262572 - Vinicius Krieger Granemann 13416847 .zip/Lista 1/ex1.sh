#!/bin/bash
clear
echo
echo "Entre com 5 valores: "
echo
read A
read B
read C
read D
read E
SOMA=0
SOMA=$(($A+$B+$C+$D+$E))
echo
echo "O valor da soma foi: $SOMA"
echo
