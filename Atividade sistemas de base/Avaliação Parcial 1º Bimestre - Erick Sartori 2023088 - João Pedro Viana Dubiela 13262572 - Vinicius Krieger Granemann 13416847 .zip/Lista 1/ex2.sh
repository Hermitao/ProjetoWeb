#!/bin/bash
clear
echo -n "Entre com o primeiro valor: "
read V1
echo -n "Entre com segundo valor: "
read V2
echo -n "Entre com o terceiro valor: "
read V3
echo -n "Entre com o quarto valor: "
read V4
echo -n "Entre com o quinto valor: "
read V5
echo -n "Entre com o sexto valor: "
read V6
SOMA=0
SOMA=$(echo "scale=2/ ($V1+$V2+$V3+$V4+$V5+$V6)"| bc)
MEDIA=0
MEDIA=$(echo "scale=2; ($SOMA/6)"| bc)
echo "A soma dos valores foi de $SOMA e a média foi $MEDIA"



